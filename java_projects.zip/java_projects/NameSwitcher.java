import java.util.ArrayList;

public class NameSwitcher {
    public static void main(String[] args) {
        ArrayList<String> names = new ArrayList<>();
        names.add("Alice");
        names.add("Bob");
        names.add("Charlie");
        names.add("Diana");
        names.add("Edward");

        System.out.println("Names = " + names);

        ArrayList<String> switchedNames = new ArrayList<>();
        for (String name : names) {
            String switchedName = switchFirstLast(name);
            switchedNames.add(switchedName);
        }

        System.out.println("Names (switched) = " + switchedNames);
    }

    private static String switchFirstLast(String name) {
        if (name.length() <= 1) {
            return name;
        }

        char firstLetter = Character.toLowerCase(name.charAt(name.length() - 1));
        char lastLetter = Character.toUpperCase(name.charAt(0));
        String middle = name.substring(1, name.length() - 1).toLowerCase();

        return lastLetter + middle + firstLetter;
    }
}
